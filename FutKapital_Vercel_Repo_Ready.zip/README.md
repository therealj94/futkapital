# FutKapital — Deploy en Vercel (SPA)

Este paquete está listo para publicar en **Vercel** con rutas tipo SPA.

## Estructura
- `index.html` — Tu aplicación.
- `vercel.json` — Reglas de _rewrite_ para evitar 404 (toda ruta sirve `index.html`).
- `404.html` — Respaldo: redirige al root.

## Pasos (GitHub → Vercel)
1) Crea un repositorio nuevo en GitHub y sube estos 3 archivos (en la raíz).
2) Ve a https://vercel.com/new → **Import Git Repository** → selecciona tu repo.
3) Framework: **Other** (Static). No build command.
4) Deploy. Obtendrás un link público para compartir.

> Si tus rutas usan hash (`#/simulador`), no dependes del server, pero `vercel.json` igual protege de 404 directos como `/simulador`.

## Problemas comunes
- 404 al recargar una ruta: asegurarse que `vercel.json` está en la raíz del repo.
- Caché del navegador: Ctrl/Cmd + Shift + R.
- Dominio personalizado: en *Project → Settings → Domains*.